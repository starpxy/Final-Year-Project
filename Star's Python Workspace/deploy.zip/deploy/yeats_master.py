from CodexMRS.core.Master import Master

Master().start_master()