#!/usr/bin/env bash
python3 csi_worker.py &