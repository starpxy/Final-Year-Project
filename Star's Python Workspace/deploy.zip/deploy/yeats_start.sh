#!/usr/bin/env bash
python3 yeats_master.py &
python3 yeats_worker.py &