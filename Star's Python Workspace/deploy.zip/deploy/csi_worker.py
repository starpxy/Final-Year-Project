from CodexMRS.core.Worker import Worker

Worker().start_up(9609,name='csiserver.ucd.ie',ip='137.43.92.165')
