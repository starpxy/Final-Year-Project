from CodexMRS.core.Worker import Worker

Worker().start_up(9610,name='yeats.ucd.ie',ip='localhost')