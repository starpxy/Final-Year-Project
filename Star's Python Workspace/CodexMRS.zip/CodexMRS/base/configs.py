config = {
    'socket_path': '.',
    'page_num': 10,
    'recall_ip': '123.206.77.77',
    'recall_port': 9609,
    'LSI_pickle_path': '/home/xingyu/yeats.pik',
    'AST_java_pickle_path': '',
    'AST_python_pickle_path': '',
    'NLP_pickle_path': ''
}
