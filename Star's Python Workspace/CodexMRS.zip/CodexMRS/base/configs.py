config = {
    'socket_path':'.'
}